$(document).ready(function() {
	$('.owl-carousel').owlCarousel({
		loop:true,
		margin:0,
		nav:true,
		dots:false,
		items:1,
		navText: [
		  "<i class='my-arrow-left'></i>",
		  "<i class='my-arrow-right'></i>"
		]
	});
});